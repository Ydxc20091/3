$ErrorActionPreference = "Stop"
$env:RUST_LOG = $env:RUST_LOG -ne $null ? $env:RUST_LOG : "info"
$bin = "target\release\qianzeV1_06.exe"
if (!(Test-Path $bin)) { cargo build --release }
& $bin