$ErrorActionPreference = "Stop"
$proj = Split-Path -Leaf (Get-Location)
Write-Host "Building $proj..."
cargo build --release
$ver = "1.6.9"
$bin = "qianzeV1_06.exe"
$out = "..\qianze_v1_06_v$ver_hotfix.zip"
if (Test-Path $out) { Remove-Item $out -Force }
Compress-Archive -Path target\release\$bin, README.md, Cargo.toml, assets.yaml, appgate_config.yaml, exit_config.yaml -DestinationPath $out
Write-Host "Done: $out"