
use anyhow::{anyhow, Context, Result};
use dotenvy::{dotenv, from_filename};
use log::{info, warn, error};
use rand::Rng;
use reqwest::Client;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::{fs, sync::Arc, time::{Duration, SystemTime, UNIX_EPOCH}};
use base64::Engine as _;

const TOKEN_PROGRAM: &str = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";

#[derive(Serialize)]
struct TradeLog<'a> {
    ts: i64,
    tag: &'a str,
    ca: &'a str,
    pair: &'a str,
    dex: Option<&'a str>,
    side: &'a str,
    price: f64,
    amount_sol: f64,
    est_cost_sol: f64,
    interval: &'a str,
    price_ts: i64,
    reason: &'a str
}
#[derive(Debug, Deserialize, Clone)]
struct AppCfg {
    #[serde(default)] prefer_interval_sec: Option<u32>,
    #[serde(default)] stale_1s_cutoff_ms: Option<u64>,
    #[serde(default)] no_buy_after_tp_sec: Option<u64>,
    #[serde(default)] no_buy_after_exit_sec: Option<u64>,

    // sizing
    #[serde(default)] amount_sol_min: Option<f64>,
    #[serde(default)] amount_sol_max: Option<f64>,
    #[serde(default = "def_amount_sol")] amount_sol: f64,

    // take profit
    #[serde(default = "def_tp_pct")] take_profit_pct: f64,
    #[serde(default = "def_tp_fixed_sell")] tp_fixed_sell_percent: f64,
    #[serde(default = "def_tp_trail_activate")] tp_trailing_activate_pct: f64,
    #[serde(default = "def_tp_trail_callback")] tp_trailing_callback_pct: f64,

    // trailing risk stop
    #[serde(default = "def_trail_full")] trail_full_pct: f64,
    #[serde(default = "def_trail_half")] trail_half_pct: f64,

    // cadence / re-entry
    #[serde(default = "def_min_cadence")] min_cadence_sec: u64,
    #[serde(default = "def_retrace_pct")] retrace_pct: f64,
    #[serde(default = "def_time_stop")] max_hold_sec: u64,
    #[serde(default = "def_reentry_cooldown")] reentry_cooldown_sec: u64,
    #[serde(default = "def_reentry_retrace")] reentry_retrace_pct: f64,

    // limits
    #[serde(default = "def_slippage")] max_slippage: f64,
    #[serde(default = "def_fee_bps")] max_fee_bps: u32,
    #[serde(default = "def_cooldown")] cooldown_sec: u64,

    // network
    #[serde(default)] jito_enabled: bool,
    #[serde(default)] priority_fee: Option<String>,
    #[serde(default)] jito_tip: Option<f64>,

    // limit baseline
    #[serde(default = "def_use_5m_close")] limit_from_5m_close: bool,
    #[serde(default)] limit_offset_pct: f64,
}

#[derive(Debug, Deserialize, Clone)]
struct AssetCfg {
    ca: String,
    #[serde(default)] amount_sol: Option<f64>,
    #[serde(default)] limit_offset_pct: Option<f64>,
}

fn def_amount_sol() -> f64 { 5.0 }
fn def_tp_pct() -> f64 { 0.02 }
fn def_tp_fixed_sell() -> f64 { 0.5 }
fn def_tp_trail_activate() -> f64 { 0.08 }
fn def_tp_trail_callback() -> f64 { 0.04 }
fn def_trail_full() -> f64 { 0.01 }
fn def_trail_half() -> f64 { 0.005 }
fn def_min_cadence() -> u64 { 180 }
fn def_retrace_pct() -> f64 { 0.008 }
fn def_time_stop() -> u64 { 12*60 }
fn def_reentry_cooldown() -> u64 { 300 }
fn def_reentry_retrace() -> f64 { 0.010 }
fn def_slippage() -> f64 { 0.03 }
fn def_fee_bps() -> u32 { 80 }
fn def_cooldown() -> u64 { 45 }
fn def_use_5m_close() -> bool { false }

#[derive(Debug, Clone)]
struct PoolCandidate { pair: String, dex: Option<String>, liq_sol: Option<f64>, fee_bps: Option<u32>, source: String }

#[allow(non_snake_case)]
#[derive(Serialize)]
struct QuickOrder<'a> {
    chain: &'a str, pair: &'a str, walletId: &'a str, r#type: &'a str,
    customFeeAndTip: bool,
    #[serde(skip_serializing_if = "Option::is_none")] priorityFee: Option<&'a str>,
    jitoEnabled: bool,
    #[serde(skip_serializing_if = "Option::is_none")] jitoTip: Option<f64>,
    maxSlippage: f64, concurrentNodes: i32, retries: i32, amountOrPercent: f64,
    #[serde(skip_serializing_if = "Option::is_none")] gasFeeDelta: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")] maxFeePerGas: Option<f64>,
}

#[derive(Debug, Deserialize, Clone)] struct TpTier { activate_pct: f64, callback_pct: f64, sell_percent: f64 }
#[derive(Debug, Default, Clone)] struct TpTierState { active: bool, peak: f64, done: bool }

#[tokio::main]
async fn main() -> Result<()> {
    env_logger::init();
    if std::fs::metadata(".evn").is_ok() { let _ = from_filename(".evn"); } else { let _ = dotenv(); }

    let api_key = std::env::var("DBOT_API_KEY").context("DBOT_API_KEY")?;
    let wallet_id = std::env::var("DBOT_WALLET_ID").context("DBOT_WALLET_ID")?;
    let trade_base = std::env::var("DBOT_TRADE_BASE").unwrap_or_else(|_| "https://api-bot-v1.dbotx.com".into());
    let data_base  = std::env::var("DBOT_DATA_BASE").unwrap_or_else(|_| "https://api-data-v1.dbotx.com".into());
    let rpc_url    = std::env::var("SOL_RPC_URL").unwrap_or_else(|_| "https://api.mainnet-beta.solana.com".into());
    let concurrent_nodes = std::env::var("DBOT_CONCURRENT_NODES").ok().and_then(|v| v.parse::<i32>().ok()).unwrap_or(3);
    let retries = std::env::var("DBOT_RETRIES").ok().and_then(|v| v.parse::<i32>().ok()).unwrap_or(1);
    let priority_fee_env = std::env::var("DBOT_PRIORITY_FEE").ok().filter(|s| !s.is_empty());

    let cfg: AppCfg = load_cfg("appgate_config.yaml").unwrap_or_else(|_| default_cfg());
    let mut assets = load_assets("assets.yaml").unwrap_or_default();
    if let Some(list) = parse_args_ca_list() {
        assets = list.into_iter().map(|ca| AssetCfg{ ca, amount_sol: None, limit_offset_pct: None }).collect();
    }
    if assets.is_empty() { return Err(anyhow!("assets list is empty. Fill assets.yaml or use --ca A,B,C")); }

    info!("multi-CA start: {} assets", assets.len());
    let client = Arc::new(Client::new());
    let mut handles = Vec::new();
    for asset in assets.into_iter() {
        let client = client.clone();
        let api_key = api_key.clone();
        let wallet_id = wallet_id.clone();
        let trade_base = trade_base.clone();
        let data_base = data_base.clone();
        let rpc_url = rpc_url.clone();
        let cfg = cfg.clone();
        let priority_fee_env = priority_fee_env.clone();
        let h = tokio::spawn(async move {
            let tag = short_tag(&asset.ca);
            let delay_ms: u64 = rand::thread_rng().gen_range(0..1200);
            tokio::time::sleep(Duration::from_millis(delay_ms)).await;
            if let Err(e) = run_worker(&tag, &client, &cfg, &asset, &priority_fee_env, &api_key, &wallet_id, &trade_base, &data_base, &rpc_url, concurrent_nodes, retries).await {
                error!("[{}] worker exit: {}", tag, e);
            }
        });
        handles.push(h);
    }
    for h in handles { let _ = h.await; }
    Ok(())
}



fn def_no_buy_after_tp_sec() -> u64 { 5 }
fn def_no_buy_after_exit_sec() -> u64 { 7 }fn def_stale_1s_cutoff_ms() -> u64 { 2500 }
fn short_tag(ca: &str) -> String { if ca.len() <= 6 { ca.to_string() } else { ca[..6].to_string() } }

fn choose_amount(amount_override: Option<f64>, cfg: &AppCfg) -> f64 {
    if let Some(v) = amount_override { return v.max(0.0); }
    match (cfg.amount_sol_min, cfg.amount_sol_max) {
        (Some(a), Some(b)) if a>0.0 && b>=a => {
            let r = rand::thread_rng().gen_range(a..=b);
            (r*1000.0).round()/1000.0 // 3位小数
        }
        _ => cfg.amount_sol.max(0.0)
    }
}

async fn run_worker(tag: &str, client: &Client, cfg: &AppCfg, asset: &AssetCfg, priority_fee_env: &Option<String>, api_key: &str, wallet_id: &str, trade_base: &str, data_base: &str, rpc_url: &str, concurrent_nodes: i32, retries: i32) -> Result<()> {
    let limit_offset_pct = asset.limit_offset_pct.unwrap_or(cfg.limit_offset_pct);
    let ca = asset.ca.clone();
    let mint = resolve_mint_via_rpc(client, rpc_url, &ca).await.unwrap_or(ca.clone());

    let mut cands = discover_pools(client, data_base, api_key, &mint).await?;
    if cands.is_empty() { cands = discover_pools_dexscreener(client, &mint).await?; }
    if cands.is_empty() { return Err(anyhow!("[{}] no pools", tag)); }
    let best = pick_best_pool(&mut cands, cfg.max_fee_bps);
    info!("[{}] pool → pair={} dex={:?} fee_bps={:?} src={}", tag, best.pair, best.dex, best.fee_bps, best.source);

    let limit_price = if cfg.limit_from_5m_close {
        let close = get_last_5m_close(client, data_base, api_key, &best.pair).await?;
        close * (1.0 + limit_offset_pct/100.0)
    } else {
        let (p, _s, _i, _t) = get_close_price_1s_or_1m(client, data_base, api_key, &best.pair, cfg.prefer_interval_sec.unwrap_or(1), cfg.stale_1s_cutoff_ms.unwrap_or(2500)).await?; p
    };
    info!("[{}] limit baseline: {:.10}", tag, limit_price);

    let tiers = load_tiers("exit_config.yaml");
    if !tiers.is_empty() { info!("[{}] tp tiers: {}", tag, tiers.len()); }

    // 状态

// 额外状态（v1.6.9）
let mut no_buy_until: i64 = 0; // 全平/止盈后短暂禁买

    let mut last_buy_ts: i64 = 0;
    let mut last_buy_price: f64 = 0.0;
    let mut last_exit_ts: i64 = 0;
    let mut last_exit_price: f64 = 0.0;

    
    // 首次运行基线（避免开盘即买）
    let mut init_price: f64 = 0.0;
    let mut warmup_done: bool = false;
let mut in_position = false;
let mut entry_price = 0.0;
    let mut peak = 0.0;
    let mut half_sold = false;
    let mut cooldown_until: i64 = 0;

    let mut tp_fixed_done = false;
    let mut tp_trailing_active = false;
    let mut tp_trail_peak = 0.0;

    let mut tier_states: Vec<TpTierState> = vec![TpTierState::default(); tiers.len()];
    let mut pos_est: f64 = 0.0;

    loop {
        let now = chrono::Utc::now().timestamp();
        if now < cooldown_until { tokio::time::sleep(Duration::from_millis(800)).await; continue; }

        // 熔断：1m 跌幅
        if let Ok(drop1m) = get_1m_drop_pct(client, data_base, api_key, &best.pair).await {
            if drop1m <= -0.06 {
                warn!("[{}] circuit breaker: 1m drop {:.2}%", tag, drop1m*100.0);
                cooldown_until = now + cfg.cooldown_sec as i64;
                continue;
            }
        }

        let (price, _src, price_interval, price_ts) = get_close_price_1s_or_1m(client, data_base, api_key, &best.pair, cfg.prefer_interval_sec.unwrap_or(1), cfg.stale_1s_cutoff_ms.unwrap_or(2500)).await?; 

        
        // 初始化：首个 tick 只记录基线，不下单
        if !warmup_done {
            init_price = price;
            warmup_done = true;
            info!("[{}] warmup baseline set @ {:.10}", tag, init_price);
            tokio::time::sleep(Duration::from_millis(500)).await;
            continue;
        }
if !in_position {
            // 1) 最小节奏
            let cadence_ok = now - last_buy_ts >= cfg.min_cadence_sec as i64;
            // 2) 相对上次买价的回撤才能加仓（避免追高）
            let retrace_ok = if last_buy_price>0.0 { price <= last_buy_price*(1.0 - cfg.retrace_pct) } else { price <= init_price*(1.0 - cfg.retrace_pct) };
            // 3) 重入保护：全平之后，需冷却时间或相对上次卖价回撤达到阈值
            let reentry_ok = if last_exit_ts == 0 {
                true
            } else {
                let since = now - last_exit_ts;
                let cooldown_ok = since >= cfg.reentry_cooldown_sec as i64;
                let retrace2_ok = price <= last_exit_price*(1.0 - cfg.reentry_retrace_pct);
                if !cooldown_ok && !retrace2_ok {
                    info!("[{}] block re-entry: since_exit={}s < {}s and retrace {:.2}% < need {:.2}%",
                        tag, since, cfg.reentry_cooldown_sec, ((last_exit_price-price)/last_exit_price*100.0).max(0.0), cfg.reentry_retrace_pct*100.0);
                }
                cooldown_ok || retrace2_ok
            };
            // 4) 限价基准（可关）
            let limit_ok   = if cfg.limit_from_5m_close { price <= limit_price } else { true };

            let nobuy_ok = now >= no_buy_until;
            if nobuy_ok && cadence_ok && reentry_ok && (limit_ok || retrace_ok) {
                let amount = choose_amount(asset.amount_sol, cfg);
                let priority_fee = priority_fee_env.as_deref().or(cfg.priority_fee.as_deref()).filter(|s| !s.is_empty());
                info!("[{}] BUY sig → price {:.10}, amount {:.3} SOL, cadence={}, limit={}, retrace={}, reentry={}",
                    tag, price, amount, cadence_ok, limit_ok, retrace_ok, reentry_ok);
                match quick_order(client, trade_base, api_key, wallet_id, &best.pair, "buy", amount, cfg.max_slippage, concurrent_nodes, retries, priority_fee, cfg.jito_enabled, cfg.jito_tip).await {
                    Ok(order_id) => {
                        in_position = true; entry_price = price; peak = price; half_sold=false;
                        last_buy_ts=now; last_buy_price=price;
                        let log = TradeLog{ ts: now, tag: &tag, ca: &mint, pair: &best.pair, dex: best.dex.as_deref(), side: "BUY", price, amount_sol: amount, est_cost_sol: amount, interval: price_interval, price_ts, reason: "signal" };
                        println!("TRADE {}", serde_json::to_string(&log).unwrap()); tp_fixed_done=false; tp_trailing_active=false; tp_trail_peak=price;
                        pos_est = 1.0; for st in &mut tier_states { *st = TpTierState::default(); }
                        info!("[{}] entered @ {:.10} (order={})", tag, entry_price, order_id.unwrap_or_else(|| "-".into()));
                    }
                    Err(e) => { error!("[{}] buy failed: {}", tag, e); }
                }
            }
        } else {
            if price > peak { peak = price; }
            let pnl = price/entry_price - 1.0;

            // 固定止盈一次
            if !tp_fixed_done && pnl >= cfg.take_profit_pct && pos_est > 0.0 {
                let sell_pct = cfg.tp_fixed_sell_percent.clamp(0.0, 1.0).min(pos_est);
                if sell_pct > 0.0 {
                    let priority_fee = priority_fee_env.as_deref().or(cfg.priority_fee.as_deref()).filter(|s| !s.is_empty());
                    info!("[{}] fixed TP {:.2}% → sell {:.0}% pos", tag, cfg.take_profit_pct*100.0, sell_pct*100.0);
                    let _ = quick_order(client, trade_base, api_key, wallet_id, &best.pair, "sell", sell_pct, cfg.max_slippage, concurrent_nodes, retries, priority_fee, cfg.jito_enabled, cfg.jito_tip).await;
                    pos_est -= sell_pct; tp_fixed_done = true; no_buy_until = now + cfg.no_buy_after_tp_sec.unwrap_or(def_no_buy_after_tp_sec()) as i64;
                    if pos_est <= 0.001 { 
                        in_position = false;
                        last_exit_ts = now;
                        no_buy_until = now + cfg.no_buy_after_exit_sec.unwrap_or(def_no_buy_after_exit_sec()) as i64; last_exit_price = price;
                        info!("[{}] exit FULL via fixed TP, start cooldown {}", tag, cfg.reentry_cooldown_sec);
                        continue;
                    }
                } else { tp_fixed_done = true; }
            }

            // 阶梯动态止盈
            let tiers_used = !tiers.is_empty();
            if tiers_used && pos_est > 0.0 {
                for (i, tier) in tiers.iter().enumerate() {
                    let st = &mut tier_states[i];
                    if st.done { continue; }
                    if !st.active && pnl >= tier.activate_pct { st.active = true; st.peak = price; info!("[{}] tp tier #{} activated at {:.2}%", tag, i+1, pnl*100.0); }
                    if st.active {
                        if price > st.peak { st.peak = price; }
                        let dd = if st.peak>0.0 { (st.peak - price)/st.peak } else { 0.0 };
                        if dd >= tier.callback_pct {
                            let sell_pct = tier.sell_percent.clamp(0.0, 1.0).min(pos_est);
                            if sell_pct > 0.0 {
                                let priority_fee = priority_fee_env.as_deref().or(cfg.priority_fee.as_deref()).filter(|s| !s.is_empty());
                                info!("[{}] tp tier #{} cb {:.2}% → sell {:.0}% pos", tag, i+1, tier.callback_pct*100.0, sell_pct*100.0);
                                let _ = quick_order(client, trade_base, api_key, wallet_id, &best.pair, "sell", sell_pct, cfg.max_slippage, concurrent_nodes, retries, priority_fee, cfg.jito_enabled, cfg.jito_tip).await;
                                pos_est -= sell_pct;
                            }
                            st.done = true;
                            if pos_est <= 0.001 {
                                in_position = false;
                        last_exit_ts = now;
                        no_buy_until = now + cfg.no_buy_after_exit_sec.unwrap_or(def_no_buy_after_exit_sec()) as i64; last_exit_price = price;
                                info!("[{}] exit FULL via tier #{} cb, start cooldown {}", tag, i+1, cfg.reentry_cooldown_sec);
                                break;
                            }
                        }
                    }
                }
                if !in_position { continue; }
            } else {
                // 单一追踪止盈（兜底）
                if !tp_trailing_active && pnl >= cfg.tp_trailing_activate_pct {
                    tp_trailing_active = true; tp_trail_peak = price;
                    info!("[{}] activate trailing TP at {:.2}%", tag, pnl*100.0);
                }
                if tp_trailing_active {
                    if price > tp_trail_peak { tp_trail_peak = price; }
                    let tdd = if tp_trail_peak>0.0 { (tp_trail_peak - price)/tp_trail_peak } else { 0.0 };
                    if tdd >= cfg.tp_trailing_callback_pct && pos_est > 0.0 {
                        let priority_fee = priority_fee_env.as_deref().or(cfg.priority_fee.as_deref()).filter(|s| !s.is_empty());
                        info!("[{}] trailing cb {:.2}% → sell ALL", tag, cfg.tp_trailing_callback_pct*100.0);
                        let _ = quick_order(client, trade_base, api_key, wallet_id, &best.pair, "sell", pos_est, cfg.max_slippage, concurrent_nodes, retries, priority_fee, cfg.jito_enabled, cfg.jito_tip).await;
                        in_position = false;
                        last_exit_ts = now;
                        no_buy_until = now + cfg.no_buy_after_exit_sec.unwrap_or(def_no_buy_after_exit_sec()) as i64; last_exit_price = price;
                        info!("[{}] exit FULL via trailing cb, start cooldown {}", tag, cfg.reentry_cooldown_sec);
                        continue;
                    }
                }
            }

            // 风险侧动态止损
            let dd = if peak>0.0 { (peak - price)/peak } else { 0.0 };
            if !half_sold && dd >= cfg.trail_half_pct && pos_est > 0.0 {
                let sell_pct = (0.5f64).min(pos_est);
                let priority_fee = priority_fee_env.as_deref().or(cfg.priority_fee.as_deref()).filter(|s| !s.is_empty());
                info!("[{}] risk trail half {:.2}% → sell {:.0}% pos", tag, dd*100.0, sell_pct*100.0);
                let _ = quick_order(client, trade_base, api_key, wallet_id, &best.pair, "sell", sell_pct, cfg.max_slippage, concurrent_nodes, retries, priority_fee, cfg.jito_enabled, cfg.jito_tip).await;
                pos_est -= sell_pct; half_sold = true;
                if pos_est <= 0.001 { 
                    in_position = false;
                        last_exit_ts = now;
                        no_buy_until = now + cfg.no_buy_after_exit_sec.unwrap_or(def_no_buy_after_exit_sec()) as i64; last_exit_price = price;
                    info!("[{}] exit FULL via risk half (rest 0), start cooldown {}", tag, cfg.reentry_cooldown_sec);
                    continue;
                }
            }
            if dd >= cfg.trail_full_pct && pos_est > 0.0 {
                let priority_fee = priority_fee_env.as_deref().or(cfg.priority_fee.as_deref()).filter(|s| !s.is_empty());
                info!("[{}] risk trail full {:.2}% → sell ALL", tag, dd*100.0);
                let _ = quick_order(client, trade_base, api_key, wallet_id, &best.pair, "sell", pos_est, cfg.max_slippage, concurrent_nodes, retries, priority_fee, cfg.jito_enabled, cfg.jito_tip).await;
                in_position = false;
                        last_exit_ts = now;
                        no_buy_until = now + cfg.no_buy_after_exit_sec.unwrap_or(def_no_buy_after_exit_sec()) as i64; last_exit_price = price;
                info!("[{}] exit FULL via risk full, start cooldown {}", tag, cfg.reentry_cooldown_sec);
                continue;
            }

            // 时间止损
            if now - last_buy_ts >= cfg.max_hold_sec as i64 && pos_est > 0.0 {
                let priority_fee = priority_fee_env.as_deref().or(cfg.priority_fee.as_deref()).filter(|s| !s.is_empty());
                warn!("[{}] time stop {}s → sell ALL", tag, cfg.max_hold_sec);
                let _ = quick_order(client, trade_base, api_key, wallet_id, &best.pair, "sell", pos_est, cfg.max_slippage, concurrent_nodes, retries, priority_fee, cfg.jito_enabled, cfg.jito_tip).await;
                in_position = false;
                        last_exit_ts = now;
                        no_buy_until = now + cfg.no_buy_after_exit_sec.unwrap_or(def_no_buy_after_exit_sec()) as i64; last_exit_price = price;
                info!("[{}] exit FULL via time stop, start cooldown {}", tag, cfg.reentry_cooldown_sec);
                continue;
            }
        }

        tokio::time::sleep(Duration::from_millis(900)).await;
    }
}

// --- loaders ---
fn load_cfg(path: &str) -> Result<AppCfg> {
    Ok(serde_yaml::from_str(&fs::read_to_string(path)?)?)
}
fn default_cfg() -> AppCfg { serde_yaml::from_str(r#"
amount_sol_min: 5.0
amount_sol_max: 8.0
amount_sol: 5.0
take_profit_pct: 0.02
tp_fixed_sell_percent: 0.5
tp_trailing_activate_pct: 0.08
tp_trailing_callback_pct: 0.04
trail_full_pct: 0.01
trail_half_pct: 0.005
min_cadence_sec: 180
retrace_pct: 0.008
reentry_cooldown_sec: 300
reentry_retrace_pct: 0.010
max_hold_sec: 720
max_slippage: 0.03
max_fee_bps: 80
cooldown_sec: 45
jito_enabled: false
priority_fee: ""
jito_tip:
limit_from_5m_close: false
limit_offset_pct: 0.0
"#).unwrap() }
fn load_assets(path: &str) -> Result<Vec<AssetCfg>> { Ok(serde_yaml::from_str(&fs::read_to_string(path)?)?) }
fn load_tiers(path: &str) -> Vec<TpTier> {
    if let Ok(s) = fs::read_to_string(path) {
        if let Ok(v) = serde_yaml::from_str::<Vec<TpTier>>(&s) {
            let mut t = v;
            t.sort_by(|a,b| a.activate_pct.partial_cmp(&b.activate_pct).unwrap());
            return t;
        }
    } vec![]
}

// --- HTTP helpers ---
#[allow(non_snake_case)]
async fn quick_order(client: &Client, trade_base: &str, api_key: &str, wallet_id: &str, pair: &str, side: &str, amount_or_percent: f64, max_slippage: f64, concurrent_nodes: i32, retries: i32, priority_fee: Option<&str>, jito_enabled: bool, jito_tip: Option<f64>) -> Result<Option<String>> {
    let payload = QuickOrder {
        chain: "solana", pair, walletId: wallet_id, r#type: side, customFeeAndTip: false,
        priorityFee: priority_fee, jitoEnabled: jito_enabled, jitoTip: if jito_enabled { jito_tip } else { None },
        maxSlippage: max_slippage, concurrentNodes: concurrent_nodes, retries, amountOrPercent: amount_or_percent,
        gasFeeDelta: None, maxFeePerGas: None,
    };
    let url = format!("{}/automation/swap_order", trade_base.trim_end_matches('/'));
    let resp = client.post(&url).header("X-API-KEY", api_key).json(&payload).send().await?;
    let status = resp.status();
    let text = resp.text().await.unwrap_or_default();
    if !status.is_success() { return Err(anyhow!("swap_order {}: {}", status, text)); }
    let v: Value = serde_json::from_str(&text).unwrap_or_default();
    if v.get("err").and_then(|x| x.as_bool()).unwrap_or(true) { return Err(anyhow!("err=true body: {}", v)); }
    let order_id = v.get("res").and_then(|r| r.get("id")).and_then(|x| x.as_str()).map(|s| s.to_string());
    Ok(order_id)
}

async fn discover_pools(client: &Client, data_base: &str, api_key: &str, mint: &str) -> Result<Vec<PoolCandidate>> {
    let mut out = vec![];
    let url_a = format!("{}/kline/search", data_base.trim_end_matches('/'));
    if let Some(v) = get_json(client, &url_a, api_key, &[("query", mint), ("chain","solana")]).await {
        if let Some(arr) = v.get("data").and_then(|d| d.as_array()) {
            for it in arr {
                if let Some(pair) = it.get("pair").or_else(|| it.get("pairAddress")).and_then(|x| x.as_str()) {
                    let dex = it.get("dex").and_then(|x| x.as_str()).map(|s| s.to_string());
                    let liq_sol = it.get("liqSOL").or_else(|| it.get("liquiditySol")).and_then(|x| x.as_f64());
                    let fee_bps = it.get("feeBps").or_else(|| it.get("tradeFeeBps")).and_then(|x| x.as_u64()).map(|x| x as u32);
                    out.push(PoolCandidate{pair:pair.to_string(), dex, liq_sol, fee_bps, source:"dbotx".into()});
                }
            }
        }
    }
    let url_b = format!("{}/token/pairs", data_base.trim_end_matches('/'));
    if out.is_empty() {
        if let Some(v) = get_json(client, &url_b, api_key, &[("address", mint), ("chain","solana")]).await {
            if let Some(arr) = v.get("data").and_then(|d| d.as_array()) {
                for it in arr {
                    if let Some(pair) = it.get("pair").or_else(|| it.get("pairAddress")).and_then(|x| x.as_str()) {
                        let dex = it.get("dex").and_then(|x| x.as_str()).map(|s| s.to_string());
                        let liq_sol = it.get("liqSOL").or_else(|| it.get("liquiditySol")).and_then(|x| x.as_f64());
                        let fee_bps = it.get("feeBps").or_else(|| it.get("tradeFeeBps")).and_then(|x| x.as_u64()).map(|x| x as u32);
                        out.push(PoolCandidate{pair:pair.to_string(), dex, liq_sol, fee_bps, source:"dbotx".into()});
                    }
                }
            }
        }
    }
    Ok(out)
}

async fn discover_pools_dexscreener(client: &Client, mint: &str) -> Result<Vec<PoolCandidate>> {
    let mut out = vec![];
    let url = format!("https://api.dexscreener.com/latest/dex/tokens/{}", mint);
    if let Ok(resp) = client.get(&url).send().await {
        if let Ok(resp_ok) = resp.error_for_status() {
            if let Ok(v) = resp_ok.json::<Value>().await {
                if let Some(pairs) = v.get("pairs").and_then(|x| x.as_array()) {
                    for p in pairs {
                        if p.get("chainId").and_then(|x| x.as_str()) != Some("solana") { continue; }
                        if let Some(pair) = p.get("pairAddress").and_then(|x| x.as_str()) {
                            let dex = p.get("dexId").and_then(|x| x.as_str()).map(|s| s.to_string());
                            let liq = p.get("liquidity").and_then(|l| l.get("usd")).and_then(|x| x.as_f64());
                            out.push(PoolCandidate{pair:pair.to_string(), dex, liq_sol: liq, fee_bps: None, source:"dexscreener".into()});
                        }
                    }
                }
            }
        }
    }
    Ok(out)
}

fn pick_best_pool(cands: &mut Vec<PoolCandidate>, max_fee_bps: u32) -> PoolCandidate {
    let default_fee_bps = 30u32;
    cands.sort_by(|a,b|{
        let fa = a.fee_bps.unwrap_or(default_fee_bps);
        let fb = b.fee_bps.unwrap_or(default_fee_bps);
        fa.cmp(&fb).then_with(|| {
            let la=a.liq_sol.unwrap_or(0.0);
            let lb=b.liq_sol.unwrap_or(0.0);
            lb.partial_cmp(&la).unwrap_or(std::cmp::Ordering::Equal)
        })
    });
    let chosen = cands.first().unwrap().clone();
    if let Some(f) = chosen.fee_bps {
        if f > max_fee_bps { warn!("chosen pool fee {} bps > max {} bps; kept for liquidity", f, max_fee_bps); }
    }
    chosen
}





// 统一获取 close 价：优先 1s（过旧则回退 1m）
// 统一获取 close 价：优先 1s（过旧或报错则回退 1m），并带短重试
// 统一获取 close 价：优先 1s（过旧或报错则回退 1m），并带短重试
async fn get_close_price_1s_or_1m(
    client: &Client,
    data_base: &str,
    api_key: &str,
    pair: &str,
    prefer_interval_sec: u32,
    stale_1s_cutoff_ms: u64,
) -> Result<(f64, &'static str, &'static str, i64)> {
    let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as i64;

    if prefer_interval_sec <= 1 {
        let url = format!("{}/kline/chart", data_base.trim_end_matches('/'));
        for attempt in 1..=2 {
            match client.get(&url)
                .header("X-API-KEY", api_key)
                .query(&[("chain","solana"),("pair",pair),("interval","1s"),("end",&now_ms.to_string())])
                .send().await
            {
                Ok(r) => {
                    if r.status().is_success() {
                        let v = r.json::<Value>().await?;
                        if let Some(last) = v.get("res").and_then(|x| x.as_array()).and_then(|a| a.last()) {
                            let close = last.get("close").and_then(|x| x.as_f64()).unwrap_or(0.0);
                            let ts = last.get("ts").or_else(|| last.get("time")).and_then(|x| x.as_i64()).unwrap_or(now_ms);
                            if close > 0.0 && (now_ms - ts) as i64 <= stale_1s_cutoff_ms as i64 {
                                return Ok((close, "kline", "1s", ts/1000));
                            } else {
                                warn!("1s kline stale/zero (age={}ms close={})", (now_ms-ts).max(0), close);
                            }
                        }
                    } else {
                        warn!("1s kline HTTP {} (attempt {}/2)", r.status(), attempt);
                    }
                }
                Err(e) => {
                    warn!("1s kline error {} (attempt {}/2)", e, attempt);
                }
            }
            tokio::time::sleep(Duration::from_millis(200 * attempt)).await;
        }
    }

    // fallback to 1m
    let url = format!("{}/kline/chart", data_base.trim_end_matches('/'));
    for attempt in 1..=2 {
        match client.get(&url)
            .header("X-API-KEY", api_key)
            .query(&[("chain","solana"),("pair",pair),("interval","1m"),("end",&now_ms.to_string())])
            .send().await
        {
            Ok(r) => {
                if r.status().is_success() {
                    let v = r.json::<Value>().await?;
                    if let Some(last) = v.get("res").and_then(|x| x.as_array()).and_then(|a| a.last()) {
                        if let Some(close) = last.get("close").and_then(|x| x.as_f64()) {
                            let ts = last.get("ts").or_else(|| last.get("time")).and_then(|x| x.as_i64()).unwrap_or(now_ms);
                            return Ok((close, "kline", "1m", ts/1000));
                        }
                    }
                } else {
                    warn!("1m kline HTTP {} (attempt {}/2)", r.status(), attempt);
                }
            }
            Err(e) => {
                warn!("1m kline error {} (attempt {}/2)", e, attempt);
            }
        }
        tokio::time::sleep(Duration::from_millis(250 * attempt)).await;
    }
    Err(anyhow!("1m kline fallback failed"))
}

async fn get_last_5m_close(client: &Client, data_base: &str, api_key: &str, pair: &str) -> Result<f64> {
    let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis().to_string();
    let url = format!("{}/kline/chart", data_base.trim_end_matches('/'));
    let v = client.get(&url)
        .header("X-API-KEY", api_key)
        .query(&[("chain","solana"),("pair",pair),("interval","5m"),("end",&now_ms)])
        .send().await?.error_for_status()?.json::<Value>().await?;
    let arr = v.get("res").and_then(|x| x.as_array()).ok_or_else(|| anyhow!("bad kline resp"))?;
    let last = arr.last().ok_or_else(|| anyhow!("no kline"))?;
    Ok(last.get("close").and_then(|x| x.as_f64()).ok_or_else(|| anyhow!("no close"))?)
}
async fn get_1m_drop_pct(client: &Client, data_base: &str, api_key: &str, pair: &str) -> Result<f64> {
    let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis().to_string();
    let url = format!("{}/kline/chart", data_base.trim_end_matches('/'));
    let v = client.get(&url)
        .header("X-API-KEY", api_key)
        .query(&[("chain","solana"),("pair",pair),("interval","1m"),("end",&now_ms)])
        .send().await?.error_for_status()?.json::<Value>().await?;
    let arr = v.get("res").and_then(|x| x.as_array()).ok_or_else(|| anyhow!("bad 1m kline"))?;
    if arr.len() < 2 { return Ok(0.0); }
    let last = arr[arr.len()-1].get("close").and_then(|x| x.as_f64()).ok_or_else(|| anyhow!("no close"))?;
    let prev = arr[arr.len()-2].get("close").and_then(|x| x.as_f64()).ok_or_else(|| anyhow!("no close"))?;
    if prev > 0.0 && last < prev { Ok((prev-last)/prev) } else { Ok(0.0) }
}

async fn get_json(client: &Client, url: &str, api_key: &str, qs: &[(&str, &str)]) -> Option<Value> {
    let req = client.get(url).header("X-API-KEY", api_key).query(qs);
    if let Ok(resp) = req.send().await {
        if let Ok(resp_ok) = resp.error_for_status() {
            if let Ok(v) = resp_ok.json::<Value>().await {
                return Some(v);
            }
        }
    }
    None
}

async fn resolve_mint_via_rpc(client: &Client, rpc_url: &str, addr: &str) -> Result<String> {
    // Get account info; if it's a token account owned by TOKEN_PROGRAM, extract mint from first 32 bytes.
    let body = serde_json::json!({
        "jsonrpc":"2.0",
        "id":1,
        "method":"getAccountInfo",
        "params":[addr, {"encoding":"base64"}]
    });
    let v: Value = client.post(rpc_url).json(&body).send().await?.error_for_status()?.json().await?;
    let value = v.get("result").and_then(|r| r.get("value")).ok_or_else(|| anyhow!("no account"))?;
    let owner = value.get("owner").and_then(|x| x.as_str()).unwrap_or_default();
    let data_arr = value.get("data").and_then(|x| x.as_array()).ok_or_else(|| anyhow!("no data arr"))?;
    let data_b64 = data_arr.get(0).and_then(|x| x.as_str()).ok_or_else(|| anyhow!("no data[0]"))?;
    let engine = base64::engine::general_purpose::STANDARD;
    let data = engine.decode(data_b64)?;
    if owner != TOKEN_PROGRAM { return Ok(addr.to_string()); }
    if data.len() <= 90 { return Ok(addr.to_string()); }
    if data.len() >= 32 { let mint_bytes = &data[0..32]; return Ok(bs58::encode(mint_bytes).into_string()); }
    Ok(addr.to_string())
}

// CLI: --ca A,B,C
fn parse_args_ca_list() -> Option<Vec<String>> {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    if args.is_empty() { return None; }
    let mut out = Vec::new(); let mut i=0;
    while i < args.len() {
        if args[i] == "--ca" && i+1 < args.len() {
            let v = args[i+1]
                .split(&[',',';',' '] as &[_])
                .filter(|s| !s.is_empty())
                .map(|s| s.to_string())
                .collect::<Vec<_>>();
            out.extend(v); i+=2;
        } else { i+=1; }
    }
    if out.is_empty() { None } else { Some(out) }
}


