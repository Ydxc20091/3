# qianzeV1.06 (v1.6.1) — 多币并行 + 重入保护 + 5–8 SOL 随机下单
- 新增：重入保护（全平仓后 300s 冷却或 ≥1% 回撤才重入）
- 新增：买入金额支持区间随机（`amount_sol_min`~`amount_sol_max`，默认 5–8 SOL）
- 默认拉长节奏（`min_cadence_sec: 180`），降低过度频繁交易

运行：
```powershell
cd .\qianzeV1.06_v1.6.1
cargo build --release
.	arget\release\qianzeV1_06.exe
# 或临时指定多币：
.	arget\release\qianzeV1_06.exe --ca CA1,CA2,CA3
```

## v1.6.9 — 热修复
- 现价统一改为 **pair 的 1s K 线 close**（无 1s 时回退 1m），避免单位不一致导致 TP 偏差
- 引入 **实价时效校验**：1s K 线落后 >2.5s 自动回退 1m
- 增加 **TP 后短暂禁买** 与 **全平后禁买**（可配置）
- 增强 **交易信息输出**（JSON），便于复盘与排错
